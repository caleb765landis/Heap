To run the Heap program, use "make run".

When the program first starts, the terminal will be cleared. The program will show the arrays and trees of the two original heaps after they have been built.

The program will merge the two heaps and create a new array from the merged heap and print the results of the new array and tree. 
